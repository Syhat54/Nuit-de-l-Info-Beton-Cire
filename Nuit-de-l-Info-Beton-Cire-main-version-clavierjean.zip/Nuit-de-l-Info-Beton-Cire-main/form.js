document.addEventListener('DOMContentLoaded', () => {

    // =============================
    // CLAVIER VIRTUEL CHAOTIQUE
    // =============================
    const nameInput = document.getElementById('name');
    const virtualKeyboard = document.getElementById('virtual-keyboard');
    const keyboardGrid = document.getElementById('keyboard-grid');

    if (nameInput && virtualKeyboard && keyboardGrid) {
        // Tous les caractères disponibles
        const allChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'.split('');

        // Fonction pour mélanger aléatoirement
        function shuffle(array) {
            const shuffled = [...array];
            for (let i = shuffled.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
            }
            return shuffled;
        }

        // Générer le clavier
        function generateKeyboard() {
            keyboardGrid.innerHTML = '';
            const shuffledChars = shuffle(allChars);

            shuffledChars.forEach(char => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'key-btn';
                btn.textContent = char;
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    nameInput.value += char;
                    generateKeyboard();
                });
                keyboardGrid.appendChild(btn);
            });

            // Bouton Espace
            const spaceBtn = document.createElement('button');
            spaceBtn.type = 'button';
            spaceBtn.className = 'key-btn space';
            spaceBtn.textContent = 'ESPACE';
            spaceBtn.addEventListener('click', (e) => {
                e.preventDefault();
                nameInput.value += ' ';
                generateKeyboard();
            });
            keyboardGrid.appendChild(spaceBtn);

            // Bouton Effacer
            const backspaceBtn = document.createElement('button');
            backspaceBtn.type = 'button';
            backspaceBtn.className = 'key-btn backspace';
            backspaceBtn.textContent = '⌫ EFFACER';
            backspaceBtn.addEventListener('click', (e) => {
                e.preventDefault();
                nameInput.value = nameInput.value.slice(0, -1);
                generateKeyboard();
            });
            keyboardGrid.appendChild(backspaceBtn);
        }

        // Afficher le clavier au clic
        nameInput.addEventListener('click', () => {
            virtualKeyboard.style.display = 'block';
            generateKeyboard();
        });
    }

    // =============================
    // AGE SELECTOR
    // =============================
    const selecteur = document.getElementById('selecteurChaos');
    const affichage = document.getElementById('valeurAge');
    const vraiInput = document.getElementById('age');

    if (selecteur && affichage && vraiInput) {
        // Créer un tableau d'âges de 1 à 100 et le mélanger
        let lesAges = Array.from({length: 100}, (_, i) => i + 1);
        lesAges.sort(() => Math.random() - 0.5);

        // Quand on bouge le curseur
        selecteur.addEventListener('input', function() {
            const agePioche = lesAges[this.value];
            affichage.textContent = agePioche;
            vraiInput.value = agePioche;
        });

        // Initialisation au chargement
        const premierAge = lesAges[0];
        affichage.textContent = premierAge;
        vraiInput.value = premierAge;
    }

    // =============================
    // PAGE RESULTATS - Affichage des données + MODE RETRO
    // =============================
    const reponseContainer = document.getElementById('contenu-reponse');

    if (reponseContainer) {
        const params = new URLSearchParams(window.location.search);
        
        const nom = params.get('name');
        const age = parseInt(params.get('age'));
        const message = params.get('message');

        // ACTIVER LE MODE RETRO SI ÂGE >= 60
        if (age >= 60) {
            document.body.classList.add('retro');
            
            // Créer et afficher le message retro
            const retroMsg = document.createElement('div');
            retroMsg.id = 'retro-message';
            retroMsg.innerHTML = '★ MODE RETRO ACTIVÉ ★<br>BIENVENUE DANS LES ANNÉES 80 !';
            document.body.appendChild(retroMsg);
            
            // Afficher le message avec animation
            setTimeout(() => {
                retroMsg.classList.add('show');
            }, 100);
            
            // Masquer le message après 3 secondes
            setTimeout(() => {
                retroMsg.classList.remove('show');
            }, 3100);
            
            // Ajouter la grille de pixels
            const pixelGrid = document.createElement('div');
            pixelGrid.id = 'pixel-grid';
            document.body.appendChild(pixelGrid);
        }

        let commentaireAge = "";
        if (!age) {
            commentaireAge = "Âge inconnu (tu as cassé le sélecteur ?)";
        } else if (age < 12) {
            commentaireAge = "Tu es un peu jeune pour manger du béton ciré, non ?";
        } else if (age >= 12 && age < 18) {
            commentaireAge = "Passe ton bac d'abord !";
        } else if (age >= 18 && age < 60) {
            commentaireAge = "La vieillesse arrive fais gaffe !";
        } else if (age >= 60 && age < 100) {
            commentaireAge = "T'es un anciennnnn, s'cuse noussss...";
        } else {
            commentaireAge = "Tu es immortel ?";
        }

        if(nom) {
            reponseContainer.innerHTML = `
                <p style="color:white; font-size:1.2rem; margin-bottom:10px;">Bonjour <strong>${nom}</strong>,</p>
                <p style="color:#F9DE2C; font-weight:bold;">${age} ans – ${commentaireAge}</p>
                <hr style="border: 0; border-top: 1px solid rgba(255,255,255,0.3); margin: 20px 0;">
                <p style="color:white; font-style:italic;">"${message}"</p>
            `;
        } else {
            reponseContainer.innerHTML = `<p style="color:white;">Aucune donnée reçue.</p>`;
        }
    }
});

// =============================
// CHATBOT TOGGLE
// =============================
function toggleChat() {
    const chatWindow = document.getElementById('chat-window');
    const iconChat = document.getElementById('icon-chat');
    const iconClose = document.getElementById('icon-close');
    
    chatWindow.classList.toggle('open');
    
    if (chatWindow.classList.contains('open')) {
        iconChat.style.display = 'none';
        iconClose.style.display = 'block';
    } else {
        iconChat.style.display = 'block';
        iconClose.style.display = 'none';
    }
}